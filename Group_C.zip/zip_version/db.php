<?php
$username = "newuser"; 
$password = "password"; 
$database = "csc350"; 
$mysqli = new mysqli("localhost", $username, $password, $database); 
?>
